//
//  ContentView.swift
//  WebViewProject
//
//  Created by 203 on 2022/06/17.
//
// UI View, UIKit 이용하여 웹페이지 띄우기

import SwiftUI

struct ContentView: View {
    var body: some View {
//        MyWebview(urlToLoad: "https://www.naver.com")

        
        NavigationView{
            
            HStack{
          //버튼을 생성
                NavigationLink(destination:
                //웹사이트 주소 설정
                    MyWebview(urlToLoad: "https://www.naver.com")
                        .edgesIgnoringSafeArea(.all)
                               
                ){
                    Text("NAVER")
                        .font(.system(size: 20))
                        .fontWeight(.bold)
                        .padding(20)
                        .background(Color.green)
                        .foregroundColor(Color.white)
                        .cornerRadius(20)
                    //버튼을 누르면 네이버 웹사이트로 이동
                }
                NavigationLink(destination:
                    MyWebview(urlToLoad: "https://www.daum.net")
                    .edgesIgnoringSafeArea(.all)
                ){
                    Text("DAUM")
                        .font(.system(size: 20))
                        .fontWeight(.bold)
                        .padding(20)
                        .background(Color.orange)
                        .foregroundColor(Color.white)
                        .cornerRadius(20)
                    //버튼을 누르면 다음 웹사이트로 이동
                }
                NavigationLink(destination:
                    MyWebview(urlToLoad: "https://www.google.com")
                    .edgesIgnoringSafeArea(.all)
                ){
                    Text("GOOGLE")
                        .font(.system(size: 20))
                        .fontWeight(.bold)
                        .padding(20)
                        .background(Color.blue)
                        .foregroundColor(Color.white)
                        .cornerRadius(20)
                    //버튼을 누르면 구글 웹사이트로 이동
                }
            }
            
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
