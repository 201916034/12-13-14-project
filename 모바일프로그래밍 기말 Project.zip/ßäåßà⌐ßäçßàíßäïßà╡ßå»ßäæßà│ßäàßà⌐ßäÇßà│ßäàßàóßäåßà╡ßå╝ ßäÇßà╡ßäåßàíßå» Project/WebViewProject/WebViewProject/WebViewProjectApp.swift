//
//  WebViewProjectApp.swift
//  WebViewProject
//
//  Created by 203 on 2022/06/17.
//

import SwiftUI

@main
struct WebViewProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
